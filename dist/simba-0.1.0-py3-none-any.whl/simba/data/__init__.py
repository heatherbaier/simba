# Ensure adapters module runs and registers datasets
from .adapters import *  # noqa: F401,F403
