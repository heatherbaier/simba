# src/simba/explain/__init__.py
from .simba import Simba